<?php
namespace qg;
qg::need('error_report');

$P = cmsBackend::install($module);
$P->Title('de','Errors');
